package com.quiz;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.quiz.dao.MyDAO;
import com.quiz.pojo.Quiz;

@Controller
public class MyController {
	
	@Autowired
	MyDAO dao;
	
	@RequestMapping("Start")
	public ModelAndView callWelcomepage()
	{
		ModelAndView mv = new ModelAndView();
		mv.setViewName("Welcome");
		return mv;
	}
	
	@RequestMapping("Welcome")
	public ModelAndView callLandingPage()
	{
		ModelAndView mv = new ModelAndView();
		mv.setViewName("LandingPage");
		return mv;
	}
	
	@RequestMapping("dattu")
	public ModelAndView calldattu(Quiz quiz)
	{
		ModelAndView mv = new ModelAndView();
		dao.save(quiz);
		mv.setViewName("dattu");
		return mv;
	}
	@RequestMapping("ExamPage")
	public ModelAndView ExamPage()
	{
		ModelAndView mv = new ModelAndView();
		mv.setViewName("ExamPage");
		return mv;
	}
	@RequestMapping("phy")
	public ModelAndView callphy()
	{
		ModelAndView mv = new ModelAndView();
		mv.setViewName("phy");
		return mv;
	}
	@RequestMapping("html")
	public ModelAndView callhtml()
	{
		ModelAndView mv = new ModelAndView();
		mv.setViewName("html");
		return mv;
	}
	@RequestMapping("ExamPage2")
	public ModelAndView callExamPage2()
	{
		ModelAndView mv = new ModelAndView();
		mv.setViewName("ExamPage2");
		return mv;
	}
	@RequestMapping("HelpPage")
	public ModelAndView calldattu2()
	{
		ModelAndView mv = new ModelAndView();
		mv.setViewName("help");
		return mv;
	}
	


}