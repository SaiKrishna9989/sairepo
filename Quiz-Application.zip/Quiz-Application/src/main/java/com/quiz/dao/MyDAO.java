package com.quiz.dao;

import org.springframework.data.repository.CrudRepository;

import com.quiz.pojo.Quiz;

public interface MyDAO extends CrudRepository<Quiz, Integer> {

}
